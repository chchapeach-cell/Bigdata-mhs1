<?php
/**
 * หน้าตรวจสอบความพร้อมระบบ API บน Hostatom (api/test.php)
 */
require_once __DIR__ . "/config.php";
header("Content-Type: text/html; charset=utf-8");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>MHS1 Database Connection Test</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 40px auto; line-height: 1.6; padding: 20px; }
    .card { background: #f9f9f9; padding: 20px; border-radius: 8px; border: 1px solid #ddd; }
    .success { color: #15803d; font-weight: bold; }
    .error { color: #b91c1c; font-weight: bold; }
  </style>
</head>
<body>
  <h2>🔍 ทดสอบการเชื่อมต่อฐานข้อมูล Hostatom MySQL</h2>
  <div class="card">
    <?php
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $ver = $pdo->query("select version()")->fetchColumn();
        echo "<p class="success">✅ เชื่อมต่อฐานข้อมูลสำเร็จสมบูรณ์!</p>";
        echo "<ul>";
        echo "<li><strong>Database Name:</strong> " . htmlspecialchars(DB_NAME) . "</li>";
        echo "<li><strong>MySQL Version:</strong> " . htmlspecialchars($ver) . "</li>";
        echo "<li><strong>Server Time:</strong> " . date("Y-m-d H:i:s") . "</li>";
        echo "</ul>";
        echo "<p>ระบบพร้อมให้บริการ REST API แล้ว คุณสามารถใช้งานเว็บไซต์ได้ตามปกติ</p>";
    } catch (PDOException $e) {
        echo "<p class="error">❌ เชื่อมต่อไม่สำเร็จ: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p>กรุณาตรวจสอบว่า:</p>";
        echo "<ol>";
        echo "<li>สร้าง Database และ User ใน cPanel เรียบร้อยแล้วหรือไม่</li>";
        echo "<li>ได้กด <strong>"Add User to Database"</strong> และให้สิทธิ์ <strong>ALL PRIVILEGES</strong> หรือยัง</li>";
        echo "<li>กรอกชื่อ DB_NAME, DB_USER, DB_PASS ใน <code>api/config.php</code> ถูกต้องครบถ้วน</li>";
        echo "</ol>";
    }
    ?>
  </div>
</body>
</html>